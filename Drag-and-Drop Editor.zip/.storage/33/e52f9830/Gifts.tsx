import GiftForCash from "@/components/social/GiftForCash";

export default function Gifts() {
  return (
    <div className="container max-w-6xl px-4 py-6 mb-16 md:mb-0">
      <GiftForCash />
    </div>
  );
}