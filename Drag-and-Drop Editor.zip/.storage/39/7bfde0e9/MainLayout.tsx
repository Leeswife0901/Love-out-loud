import { useState } from "react";
import { Outlet, Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  BellIcon,
  HomeIcon,
  SearchIcon,
  HeartIcon,
  VideoIcon,
  PlusIcon,
  UserIcon,
  LogInIcon,
  MenuIcon,
  MessageCircleIcon,
  HandIcon,
  GiftIcon
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/context/AuthContext";

export default function MainLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Navigation */}
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <div className="mr-4 flex">
            <Link to="/" className="flex items-center space-x-2">
              <HeartIcon className="h-6 w-6 text-violet-600" />
              <span className="font-bold text-xl">Love Out Loud</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="flex-1 flex justify-center md:justify-start">
            <div className="hidden md:flex md:items-center md:gap-6">
              <Link to="/">
                <Button
                  variant={isActive("/") ? "default" : "ghost"}
                  size="sm"
                  className={isActive("/") ? "bg-violet-600 hover:bg-violet-700" : ""}
                >
                  <HomeIcon className="h-4 w-4 mr-2" />
                  Home
                </Button>
              </Link>
              <Link to="/explore">
                <Button
                  variant={isActive("/explore") ? "default" : "ghost"}
                  size="sm"
                  className={isActive("/explore") ? "bg-violet-600 hover:bg-violet-700" : ""}
                >
                  <SearchIcon className="h-4 w-4 mr-2" />
                  Explore
                </Button>
              </Link>
              <Link to="/gifts">
                <Button
                  variant={isActive("/gifts") ? "default" : "ghost"}
                  size="sm"
                  className={isActive("/gifts") ? "bg-violet-600 hover:bg-violet-700" : ""}
                >
                  <GiftIcon className="h-4 w-4 mr-2" />
                  Gifts
                </Button>
              </Link>
              <Link to="/fundraisers">
                <Button
                  variant={isActive("/fundraisers") ? "default" : "ghost"}
                  size="sm"
                  className={isActive("/fundraisers") ? "bg-violet-600 hover:bg-violet-700" : ""}
                >
                  <HandIcon className="h-4 w-4 mr-2" />
                  Support
                </Button>
              </Link>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="shrink-0">
                  <MenuIcon className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <SheetHeader className="mb-4">
                  <SheetTitle>UrbanVibe</SheetTitle>
                </SheetHeader>
                <div className="grid gap-2 py-4">
                  <Link to="/" onClick={closeMobileMenu}>
                    <Button
                      variant={isActive("/") ? "default" : "ghost"}
                      size="sm"
                      className="w-full justify-start"
                    >
                      <HomeIcon className="h-4 w-4 mr-2" />
                      Home
                    </Button>
                  </Link>
                  <Link to="/explore" onClick={closeMobileMenu}>
                    <Button
                      variant={isActive("/explore") ? "default" : "ghost"}
                      size="sm"
                      className="w-full justify-start"
                    >
                      <SearchIcon className="h-4 w-4 mr-2" />
                      Explore
                    </Button>
                  </Link>
                  <Link to="/journal" onClick={closeMobileMenu}>
                    <Button
                      variant={isActive("/journal") ? "default" : "ghost"}
                      size="sm"
                      className="w-full justify-start"
                    >
                      <VideoIcon className="h-4 w-4 mr-2" />
                      Daily Journal
                    </Button>
                  </Link>
                  <Link to="/gifts" onClick={closeMobileMenu}>
                    <Button
                      variant={isActive("/gifts") ? "default" : "ghost"}
                      size="sm"
                      className="w-full justify-start"
                    >
                      <GiftIcon className="h-4 w-4 mr-2" />
                      Gifts
                    </Button>
                  </Link>
                  <Link to="/fundraisers" onClick={closeMobileMenu}>
                    <Button
                      variant={isActive("/fundraisers") ? "default" : "ghost"}
                      size="sm"
                      className="w-full justify-start"
                    >
                      <HandIcon className="h-4 w-4 mr-2" />
                      Support Inmates
                    </Button>
                  </Link>
                  <Link to="/messages" onClick={closeMobileMenu}>
                    <Button
                      variant={isActive("/messages") ? "default" : "ghost"}
                      size="sm"
                      className="w-full justify-start"
                    >
                      <MessageCircleIcon className="h-4 w-4 mr-2" />
                      Messages
                    </Button>
                  </Link>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Search Bar (hidden on small screens) */}
          <div className="hidden md:flex md:flex-1 md:items-center md:justify-center px-4">
            <div className="relative w-full max-w-sm">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <input
                type="search"
                placeholder="Search..."
                className="h-9 w-full rounded-md border border-input bg-background pl-8 pr-3 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
            </div>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-1">
            <Link to="/notifications">
              <Button variant="ghost" size="icon">
                <BellIcon className="h-5 w-5" />
              </Button>
            </Link>
            <Link to="/create">
              <Button variant="ghost" size="icon" className="hidden md:flex">
                <PlusIcon className="h-5 w-5" />
              </Button>
            </Link>

            {currentUser ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={currentUser.avatar} />
                      <AvatarFallback>{currentUser.username.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <div className="flex items-center justify-start gap-2 p-2">
                    <div className="flex flex-col space-y-1 leading-none">
                      <p className="font-medium">{currentUser.displayName || currentUser.username}</p>
                      <p className="text-xs text-muted-foreground">@{currentUser.username}</p>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to={`/profile/${currentUser.username}`} className="cursor-pointer">
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/settings" className="cursor-pointer">
                      Settings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link to="/login">
                <Button size="sm" className="bg-violet-600 hover:bg-violet-700">
                  <LogInIcon className="h-4 w-4 mr-2" />
                  Login
                </Button>
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Bottom Navigation (Mobile) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 border-t bg-background z-40">
        <div className="grid grid-cols-5 h-14">
          <Link to="/" className="flex flex-col items-center justify-center">
            <HomeIcon className={`h-5 w-5 ${isActive("/") ? "text-violet-600" : ""}`} />
            <span className="text-xs mt-1">Home</span>
          </Link>
          <Link to="/explore" className="flex flex-col items-center justify-center">
            <SearchIcon className={`h-5 w-5 ${isActive("/explore") ? "text-violet-600" : ""}`} />
            <span className="text-xs mt-1">Explore</span>
          </Link>
          <Link to="/create" className="flex flex-col items-center justify-center">
            <div className="h-12 w-12 rounded-full bg-violet-600 flex items-center justify-center -mt-6">
              <PlusIcon className="h-6 w-6 text-white" />
            </div>
          </Link>
          <Link to="/journal" className="flex flex-col items-center justify-center">
            <VideoIcon className={`h-5 w-5 ${isActive("/journal") ? "text-violet-600" : ""}`} />
            <span className="text-xs mt-1">Journal</span>
          </Link>
          <Link to={currentUser ? `/profile/${currentUser.username}` : "/login"} className="flex flex-col items-center justify-center">
            <UserIcon className={`h-5 w-5 ${isActive(`/profile/${currentUser?.username}`) ? "text-violet-600" : ""}`} />
            <span className="text-xs mt-1">Profile</span>
          </Link>
        </div>
      </nav>
    </div>
  );
}