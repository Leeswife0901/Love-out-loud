import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { 
  HandIcon, 
  HeartIcon, 
  PlusIcon, 
  ShareIcon, 
  StarIcon,
  UserIcon,
  Building2Icon,
  CalendarIcon
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import PaymentInterface from "@/components/payments/PaymentInterface";

interface Fundraiser {
  id: string;
  inmateId: string;
  inmateName: string;
  inmatePhoto?: string;
  facilityName: string;
  facilityLocation: string;
  goalAmount: number;
  raisedAmount: number;
  description: string;
  createdBy: string;
  creatorId: string;
  creatorAvatar?: string;
  dueDate?: string;
}

export default function InmateFundraiser() {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState("browse");
  const [fundraisers, setFundraisers] = useState<Fundraiser[]>(() => {
    // Get from localStorage in demo or initialize with default data
    const storedFundraisers = localStorage.getItem("inmate_fundraisers");
    if (storedFundraisers) {
      return JSON.parse(storedFundraisers);
    }
    
    // Example fundraisers
    const defaultFundraisers: Fundraiser[] = [
      {
        id: "fund1",
        inmateId: "12345",
        inmateName: "Marcus Johnson",
        inmatePhoto: "https://api.dicebear.com/7.x/micah/svg?seed=Marcus",
        facilityName: "Central Correctional Facility",
        facilityLocation: "Los Angeles, CA",
        goalAmount: 1500,
        raisedAmount: 875,
        description: "Help Marcus get access to educational resources including books and online courses so he can prepare for his future once released.",
        createdBy: "family_support",
        creatorId: "user123",
        creatorAvatar: "https://api.dicebear.com/7.x/micah/svg?seed=family",
        dueDate: "2025-10-15"
      },
      {
        id: "fund2",
        inmateId: "67890",
        inmateName: "Darnell Williams",
        inmatePhoto: "https://api.dicebear.com/7.x/micah/svg?seed=Darnell",
        facilityName: "Riverdale Correctional",
        facilityLocation: "Atlanta, GA",
        goalAmount: 800,
        raisedAmount: 310,
        description: "Darnell needs support for legal fees to help with his appeal case. Every contribution brings him closer to justice.",
        createdBy: "legal_aid",
        creatorId: "user456",
        creatorAvatar: "https://api.dicebear.com/7.x/micah/svg?seed=legal",
        dueDate: "2025-09-20"
      }
    ];
    
    localStorage.setItem("inmate_fundraisers", JSON.stringify(defaultFundraisers));
    return defaultFundraisers;
  });
  
  const [newFundraiser, setNewFundraiser] = useState({
    inmateName: "",
    inmateId: "",
    facilityName: "",
    facilityLocation: "",
    goalAmount: "",
    description: "",
    dueDate: ""
  });
  
  const [selectedFundraiser, setSelectedFundraiser] = useState<Fundraiser | null>(null);
  const [donationAmount, setDonationAmount] = useState("");
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewFundraiser(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleCreateFundraiser = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      toast.error("You need to be logged in to create a fundraiser");
      return;
    }
    
    // Validate form
    if (!newFundraiser.inmateName || !newFundraiser.facilityName || 
        !newFundraiser.goalAmount || !newFundraiser.description) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    // Create new fundraiser
    const fundraiser: Fundraiser = {
      id: `fund_${Date.now()}`,
      inmateId: newFundraiser.inmateId || `inmate_${Date.now()}`,
      inmateName: newFundraiser.inmateName,
      facilityName: newFundraiser.facilityName,
      facilityLocation: newFundraiser.facilityLocation,
      goalAmount: parseFloat(newFundraiser.goalAmount),
      raisedAmount: 0,
      description: newFundraiser.description,
      createdBy: currentUser.username,
      creatorId: currentUser.id,
      creatorAvatar: currentUser.avatar,
      dueDate: newFundraiser.dueDate
    };
    
    // Add to state and localStorage
    const updatedFundraisers = [...fundraisers, fundraiser];
    setFundraisers(updatedFundraisers);
    localStorage.setItem("inmate_fundraisers", JSON.stringify(updatedFundraisers));
    
    // Reset form and switch to browse tab
    setNewFundraiser({
      inmateName: "",
      inmateId: "",
      facilityName: "",
      facilityLocation: "",
      goalAmount: "",
      description: "",
      dueDate: ""
    });
    
    toast.success("Fundraiser created successfully");
    setActiveTab("browse");
  };
  
  const handleSelectFundraiser = (fundraiser: Fundraiser) => {
    setSelectedFundraiser(fundraiser);
    setActiveTab("donate");
  };
  
  const handleDonationSubmit = () => {
    const amount = parseFloat(donationAmount);
    
    if (!amount || amount <= 0) {
      toast.error("Please enter a valid donation amount");
      return;
    }
    
    if (!selectedFundraiser) {
      toast.error("No fundraiser selected");
      return;
    }
    
    setShowPaymentForm(true);
  };
  
  const handlePaymentComplete = (paymentMethod: string, paymentId: string) => {
    // In a real app, this would process the payment through the backend
    // For demo purposes, we'll just update the local state
    
    if (!selectedFundraiser) return;
    
    const amount = parseFloat(donationAmount);
    
    // Update the fundraiser
    const updatedFundraisers = fundraisers.map(f => {
      if (f.id === selectedFundraiser.id) {
        return {
          ...f,
          raisedAmount: f.raisedAmount + amount
        };
      }
      return f;
    });
    
    setFundraisers(updatedFundraisers);
    localStorage.setItem("inmate_fundraisers", JSON.stringify(updatedFundraisers));
    
    // Reset state
    setDonationAmount("");
    setShowPaymentForm(false);
    
    toast.success(`Thank you for your donation of $${amount} via ${paymentMethod}!`);
    setActiveTab("browse");
  };
  
  function FundraiserCard({ fundraiser, onSelect }: { fundraiser: Fundraiser, onSelect: (fundraiser: Fundraiser) => void }) {
    const progress = (fundraiser.raisedAmount / fundraiser.goalAmount) * 100;
    
    const getDaysRemaining = () => {
      if (!fundraiser.dueDate) return "No deadline";
      
      const dueDate = new Date(fundraiser.dueDate);
      const today = new Date();
      const diffTime = dueDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      return diffDays > 0 ? `${diffDays} days left` : "Ended";
    };
    
    return (
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12">
                <AvatarImage src={fundraiser.inmatePhoto || `https://api.dicebear.com/7.x/micah/svg?seed=${fundraiser.inmateName}`} />
                <AvatarFallback>{fundraiser.inmateName.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-lg">{fundraiser.inmateName}</CardTitle>
                <CardDescription className="flex items-center gap-1">
                  <Building2Icon className="h-3 w-3" />
                  {fundraiser.facilityName}
                </CardDescription>
              </div>
            </div>
            <div className="text-sm text-right">
              <div className="font-medium">${fundraiser.raisedAmount.toLocaleString()}</div>
              <div className="text-muted-foreground text-xs">raised of ${fundraiser.goalAmount.toLocaleString()}</div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Progress value={progress} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>{progress.toFixed(0)}% Complete</span>
                <span className="flex items-center gap-1">
                  <CalendarIcon className="h-3 w-3" />
                  {getDaysRemaining()}
                </span>
              </div>
            </div>
            
            <p className="text-sm line-clamp-2">
              {fundraiser.description}
            </p>
          </div>
        </CardContent>
        <CardFooter className="pt-0 flex justify-between">
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <UserIcon className="h-3 w-3" />
            Created by {fundraiser.createdBy}
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm">
              <ShareIcon className="h-4 w-4 mr-1" />
              Share
            </Button>
            <Button 
              size="sm"
              onClick={() => onSelect(fundraiser)}
              className="bg-violet-600 hover:bg-violet-700"
            >
              <HeartIcon className="h-4 w-4 mr-1" />
              Support
            </Button>
          </div>
        </CardFooter>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Support Inmates</h1>
          <p className="text-muted-foreground mt-1">
            Help inmates with education, legal resources, and essential needs
          </p>
        </div>
        
        {currentUser && (
          <Button 
            onClick={() => setActiveTab("create")}
            className="bg-violet-600 hover:bg-violet-700 self-start"
          >
            <PlusIcon className="h-4 w-4 mr-2" />
            Create Fundraiser
          </Button>
        )}
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="browse">Browse</TabsTrigger>
          <TabsTrigger value="donate" disabled={!selectedFundraiser && activeTab !== "donate"}>
            Donate
          </TabsTrigger>
          <TabsTrigger value="create" disabled={!currentUser}>
            Create
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="browse" className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {fundraisers.map(fundraiser => (
              <FundraiserCard 
                key={fundraiser.id}
                fundraiser={fundraiser}
                onSelect={handleSelectFundraiser}
              />
            ))}
            
            {fundraisers.length === 0 && (
              <div className="col-span-full text-center py-12">
                <HandIcon className="h-16 w-16 mx-auto text-muted-foreground opacity-40" />
                <h3 className="text-xl font-medium mt-4">No fundraisers yet</h3>
                <p className="text-muted-foreground mt-2">
                  Be the first to create a fundraiser for an inmate
                </p>
              </div>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="donate" className="pt-6">
          {selectedFundraiser && (
            <div className="max-w-2xl mx-auto">
              {!showPaymentForm ? (
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={selectedFundraiser.inmatePhoto || `https://api.dicebear.com/7.x/micah/svg?seed=${selectedFundraiser.inmateName}`} />
                        <AvatarFallback>{selectedFundraiser.inmateName.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle>Support {selectedFundraiser.inmateName}</CardTitle>
                        <CardDescription>
                          {selectedFundraiser.facilityName}, {selectedFundraiser.facilityLocation}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="mb-4">{selectedFundraiser.description}</p>
                      
                      <div className="bg-violet-50 dark:bg-gray-800 p-4 rounded-lg space-y-3">
                        <div className="flex justify-between items-baseline">
                          <span className="text-sm font-medium">Fundraising Progress</span>
                          <span className="text-sm">${selectedFundraiser.raisedAmount} of ${selectedFundraiser.goalAmount}</span>
                        </div>
                        <Progress value={(selectedFundraiser.raisedAmount / selectedFundraiser.goalAmount) * 100} className="h-2" />
                      </div>
                    </div>
                    
                    <div className="pt-4 space-y-4">
                      <h3 className="font-medium flex items-center gap-2">
                        <HeartIcon className="h-5 w-5 text-violet-600" />
                        Enter your donation amount
                      </h3>
                      
                      <div className="grid grid-cols-4 gap-2">
                        {[10, 25, 50, 100].map(amount => (
                          <Button
                            key={amount}
                            variant="outline"
                            onClick={() => setDonationAmount(amount.toString())}
                            className={`h-16 ${donationAmount === amount.toString() ? 'border-violet-600 bg-violet-50' : ''}`}
                          >
                            ${amount}
                          </Button>
                        ))}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="custom-amount">Custom amount</Label>
                        <div className="relative">
                          <span className="absolute left-3 top-2.5">$</span>
                          <Input
                            id="custom-amount"
                            type="number"
                            placeholder="Enter amount"
                            value={donationAmount}
                            onChange={(e) => setDonationAmount(e.target.value)}
                            className="pl-7"
                            min="1"
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end pt-2">
                    <Button 
                      onClick={handleDonationSubmit}
                      className="bg-violet-600 hover:bg-violet-700"
                      disabled={!donationAmount || parseFloat(donationAmount) <= 0}
                    >
                      Continue to Payment
                    </Button>
                  </CardFooter>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Complete your donation</CardTitle>
                    <CardDescription>
                      You're donating ${donationAmount} to support {selectedFundraiser.inmateName}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <PaymentInterface 
                      amount={parseFloat(donationAmount)}
                      onPaymentComplete={handlePaymentComplete}
                      description={`Donation for ${selectedFundraiser.inmateName}`}
                    />
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="create" className="pt-6">
          {currentUser ? (
            <Card>
              <CardHeader>
                <CardTitle>Create a Fundraiser</CardTitle>
                <CardDescription>
                  Set up a fundraiser to help an inmate with education, legal fees, or essential needs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreateFundraiser} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="inmateName">Inmate Name *</Label>
                      <Input
                        id="inmateName"
                        name="inmateName"
                        placeholder="Full name of the inmate"
                        value={newFundraiser.inmateName}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="inmateId">Inmate ID (if known)</Label>
                      <Input
                        id="inmateId"
                        name="inmateId"
                        placeholder="ID number of the inmate"
                        value={newFundraiser.inmateId}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="facilityName">Facility Name *</Label>
                      <Input
                        id="facilityName"
                        name="facilityName"
                        placeholder="Name of the correctional facility"
                        value={newFundraiser.facilityName}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="facilityLocation">Facility Location</Label>
                      <Input
                        id="facilityLocation"
                        name="facilityLocation"
                        placeholder="City, State"
                        value={newFundraiser.facilityLocation}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="goalAmount">Fundraising Goal ($) *</Label>
                      <Input
                        id="goalAmount"
                        name="goalAmount"
                        type="number"
                        min="1"
                        placeholder="Amount needed"
                        value={newFundraiser.goalAmount}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="dueDate">End Date (Optional)</Label>
                      <Input
                        id="dueDate"
                        name="dueDate"
                        type="date"
                        value={newFundraiser.dueDate}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2 pt-2">
                    <Label htmlFor="description">Description *</Label>
                    <Textarea
                      id="description"
                      name="description"
                      placeholder="Describe why you're fundraising and how the money will help"
                      value={newFundraiser.description}
                      onChange={handleInputChange}
                      className="min-h-[120px]"
                      required
                    />
                  </div>
                  
                  <div className="bg-violet-50 dark:bg-gray-800 p-4 rounded-lg text-sm">
                    <p className="flex items-center gap-2">
                      <StarIcon className="h-4 w-4 text-violet-600" />
                      <span className="font-medium">Important:</span> All fundraisers are verified before funds are disbursed
                    </p>
                    <p className="mt-2 text-muted-foreground pl-6">
                      We work directly with correctional facilities to ensure donations reach the intended inmates.
                    </p>
                  </div>
                </form>
              </CardContent>
              <CardFooter className="flex justify-end gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => setActiveTab("browse")}
                >
                  Cancel
                </Button>
                <Button 
                  type="button" 
                  onClick={handleCreateFundraiser}
                  className="bg-violet-600 hover:bg-violet-700"
                >
                  Create Fundraiser
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <div className="text-center py-12">
              <HandIcon className="h-16 w-16 mx-auto text-muted-foreground opacity-40" />
              <h3 className="text-xl font-medium mt-4">Login Required</h3>
              <p className="text-muted-foreground mt-2 mb-6">
                You need to be logged in to create a fundraiser
              </p>
              <Button 
                onClick={() => window.location.href = "/login"}
                className="bg-violet-600 hover:bg-violet-700"
              >
                Login to Continue
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}