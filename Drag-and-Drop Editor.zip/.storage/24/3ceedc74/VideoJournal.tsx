import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { VideoIcon, StopCircleIcon, SendIcon, HeartIcon, UserIcon } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";

interface VideoJournalProps {
  onPostComplete: () => void;
}

export default function VideoJournal({ onPostComplete }: VideoJournalProps) {
  const { currentUser } = useAuth();
  const [isRecording, setIsRecording] = useState(false);
  const [videoURL, setVideoURL] = useState<string | null>(null);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [description, setDescription] = useState("");
  const [recipients, setRecipients] = useState("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<number | null>(null);

  // Cleanup function
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      
      const recorder = new MediaRecorder(stream);
      setMediaRecorder(recorder);
      
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = e => {
        if (e.data.size > 0) {
          chunks.push(e.data);
        }
      };
      
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: "video/webm" });
        const url = URL.createObjectURL(blob);
        setVideoURL(url);
        
        if (videoRef.current) {
          videoRef.current.srcObject = null;
          videoRef.current.src = url;
          videoRef.current.controls = true;
        }
        
        if (timerRef.current) {
          window.clearInterval(timerRef.current);
        }
      };
      
      recorder.start();
      setIsRecording(true);
      
      // Timer for recording duration
      setRecordingTime(0);
      timerRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
    } catch (error) {
      toast.error("Failed to access camera and microphone. Please check permissions.");
      console.error("Error accessing media devices:", error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
      
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  const handlePost = async () => {
    if (!videoURL) {
      toast.error("Please record a video first");
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // In a real app, this would upload the video to a server
      // For demo purposes, we'll simulate a successful upload with a delay
      
      setTimeout(() => {
        // Create a post object
        const post = {
          id: `post_${Date.now()}`,
          userId: currentUser?.id || "guest",
          username: currentUser?.username || "Guest",
          userAvatar: currentUser?.avatar,
          content: description,
          mediaUrl: videoURL, // In a real app, this would be a URL from your storage service
          likes: 0,
          comments: 0,
          timestamp: new Date().toISOString(),
          isPremium: false,
          type: "journal",
          recipients: recipients.split(',').map(r => r.trim()),
        };
        
        // Store in localStorage (in a real app, this would go to a database)
        const posts = JSON.parse(localStorage.getItem("urbanvibe_posts") || "[]");
        posts.unshift(post);
        localStorage.setItem("urbanvibe_posts", JSON.stringify(posts));
        
        toast.success("Journal video posted successfully!");
        setIsProcessing(false);
        onPostComplete();
        
        // Reset form
        setVideoURL(null);
        setDescription("");
        setRecipients("");
        
      }, 2000);
    } catch (error) {
      toast.error("Failed to post video");
      setIsProcessing(false);
    }
  };

  const resetRecording = () => {
    if (videoURL) {
      URL.revokeObjectURL(videoURL);
      setVideoURL(null);
    }
    
    if (videoRef.current) {
      videoRef.current.controls = false;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <VideoIcon className="h-5 w-5 text-violet-600" />
          Daily Video Journal
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative bg-black rounded-md overflow-hidden aspect-video">
          {!videoURL && !isRecording && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
              <VideoIcon className="h-12 w-12 mb-2 opacity-70" />
              <p className="text-sm opacity-70">Press Record to start your daily journal</p>
            </div>
          )}
          
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted={isRecording}
            className="w-full h-full object-cover"
          />
          
          {isRecording && (
            <div className="absolute top-4 right-4 bg-red-600 px-3 py-1 rounded-full text-white text-xs font-medium flex items-center gap-1">
              <span className="h-2 w-2 bg-white rounded-full animate-pulse"></span>
              REC {formatTime(recordingTime)}
            </div>
          )}
        </div>

        <div className="flex gap-2">
          {!isRecording && !videoURL && (
            <Button 
              onClick={startRecording} 
              className="flex-1 bg-violet-600 hover:bg-violet-700"
            >
              <VideoIcon className="h-4 w-4 mr-2" />
              Record Journal
            </Button>
          )}
          
          {isRecording && (
            <Button 
              onClick={stopRecording} 
              variant="destructive"
              className="flex-1"
            >
              <StopCircleIcon className="h-4 w-4 mr-2" />
              Stop Recording
            </Button>
          )}
          
          {videoURL && (
            <Button 
              onClick={resetRecording}
              variant="outline"
              className="flex-1"
            >
              Record Again
            </Button>
          )}
        </div>
        
        <div className="space-y-2">
          <label className="text-sm font-medium">Share with loved ones (comma-separated usernames)</label>
          <div className="flex items-center gap-2 border rounded-md p-2">
            <UserIcon className="h-4 w-4 text-gray-400" />
            <Input
              value={recipients}
              onChange={(e) => setRecipients(e.target.value)}
              placeholder="mom, dad, sister123"
              className="border-0 p-0 focus-visible:ring-0"
            />
          </div>
        </div>

        <Textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Add a description for your daily journal..."
          className="min-h-24"
        />
      </CardContent>
      <CardFooter className="flex justify-end">
        <Button 
          onClick={handlePost}
          disabled={!videoURL || isProcessing}
          className="bg-violet-600 hover:bg-violet-700"
        >
          {isProcessing ? (
            <>Processing...</>
          ) : (
            <>
              <HeartIcon className="h-4 w-4 mr-2" />
              Share Journal
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}