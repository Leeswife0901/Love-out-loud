import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { HandIcon, ArrowRightIcon, LockIcon, HeartIcon } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import PaymentInterface from "../payments/PaymentInterface";

interface Fundraiser {
  id: string;
  inmateId: string;
  inmateName: string;
  inmateLocation: string;
  inmateImage: string;
  title: string;
  description: string;
  goal: number;
  raised: number;
  createdBy: string;
  creatorId: string;
  createdAt: string;
  supporters: number;
}

interface FundraiserCardProps {
  fundraiser: Fundraiser;
  onDonate: (fundraiser: Fundraiser) => void;
}

function FundraiserCard({ fundraiser, onDonate }: FundraiserCardProps) {
  const progress = (fundraiser.raised / fundraiser.goal) * 100;
  const remainingAmount = fundraiser.goal - fundraiser.raised;

  return (
    <Card className="overflow-hidden">
      <div className="aspect-video bg-gray-100 relative overflow-hidden">
        <img 
          src={fundraiser.inmateImage || `https://api.dicebear.com/7.x/initials/svg?seed=${fundraiser.inmateName}`}
          alt={fundraiser.inmateName}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
          <div className="p-4 text-white">
            <h4 className="font-bold">{fundraiser.inmateName}</h4>
            <p className="text-sm opacity-90">{fundraiser.inmateLocation}</p>
          </div>
        </div>
      </div>
      
      <CardHeader>
        <CardTitle>{fundraiser.title}</CardTitle>
        <CardDescription>Created by {fundraiser.createdBy}</CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-1.5">
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between text-sm">
            <span className="font-medium">${fundraiser.raised.toFixed(2)} raised</span>
            <span className="text-muted-foreground">${fundraiser.goal.toFixed(2)} goal</span>
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground line-clamp-3">
          {fundraiser.description}
        </p>
        
        <div className="flex items-center text-sm text-muted-foreground">
          <HeartIcon className="h-4 w-4 mr-1 text-red-500" />
          <span>{fundraiser.supporters} supporters</span>
        </div>
      </CardContent>
      
      <CardFooter>
        <Button 
          onClick={() => onDonate(fundraiser)} 
          className="w-full bg-violet-600 hover:bg-violet-700"
        >
          <HandIcon className="h-4 w-4 mr-2" />
          Donate
        </Button>
      </CardFooter>
    </Card>
  );
}

interface CreateFundraiserDialogProps {
  onCreate: (fundraiser: Omit<Fundraiser, "id" | "raised" | "supporters" | "createdAt">) => void;
}

function CreateFundraiserDialog({ onCreate }: CreateFundraiserDialogProps) {
  const { currentUser } = useAuth();
  const [formData, setFormData] = useState({
    inmateName: "",
    inmateId: "",
    inmateLocation: "",
    inmateImage: "",
    title: "",
    description: "",
    goal: 500
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) return;
    
    onCreate({
      ...formData,
      creatorId: currentUser.id,
      createdBy: currentUser.username,
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === "goal" ? parseFloat(value) : value
    }));
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button className="w-full">Create New Fundraiser</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create Inmate Fundraiser</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Inmate Name</label>
            <Input
              name="inmateName"
              value={formData.inmateName}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Inmate ID (optional)</label>
            <Input
              name="inmateId"
              value={formData.inmateId}
              onChange={handleChange}
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Facility Location</label>
            <Input
              name="inmateLocation"
              value={formData.inmateLocation}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Image URL (optional)</label>
            <Input
              name="inmateImage"
              value={formData.inmateImage}
              onChange={handleChange}
              placeholder="https://example.com/image.jpg"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Fundraiser Title</label>
            <Input
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Description</label>
            <Textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
              className="min-h-24"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Goal Amount ($)</label>
            <Input
              name="goal"
              type="number"
              min="10"
              value={formData.goal}
              onChange={handleChange}
              required
            />
          </div>
          
          <Button type="submit" className="w-full">Create Fundraiser</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function InmateFundraiser() {
  const { currentUser } = useAuth();
  const [fundraisers, setFundraisers] = useState<Fundraiser[]>(() => {
    const storedFundraisers = localStorage.getItem("urbanvibe_fundraisers");
    if (storedFundraisers) {
      return JSON.parse(storedFundraisers);
    }
    return [
      {
        id: "fr1",
        inmateId: "A12345",
        inmateName: "James Wilson",
        inmateLocation: "Central State Correctional Facility",
        inmateImage: "https://api.dicebear.com/7.x/micah/svg?seed=James",
        title: "Education Fund for James",
        description: "Help James gain access to educational materials and courses while serving his time. Your contribution will directly fund books, online courses, and other educational resources to help him prepare for a better future upon release.",
        goal: 1500,
        raised: 780,
        createdBy: "sarah_j",
        creatorId: "user123",
        createdAt: "2023-05-15T12:30:00Z",
        supporters: 14
      },
      {
        id: "fr2",
        inmateId: "B78901",
        inmateName: "Michael Brown",
        inmateLocation: "Westview Rehabilitation Center",
        inmateImage: "https://api.dicebear.com/7.x/micah/svg?seed=Michael",
        title: "Family Connection for Michael",
        description: "Michael hasn't seen his children in over 2 years due to transportation costs. Help his family visit him monthly by contributing to their travel expenses. Every dollar helps reconnect this family.",
        goal: 2000,
        raised: 450,
        createdBy: "mark_h",
        creatorId: "user456",
        createdAt: "2023-06-22T09:15:00Z",
        supporters: 8
      }
    ];
  });
  
  const [selectedFundraiser, setSelectedFundraiser] = useState<Fundraiser | null>(null);
  const [showDonate, setShowDonate] = useState(false);
  const [donationAmount, setDonationAmount] = useState(1000); // $10.00

  useEffect(() => {
    localStorage.setItem("urbanvibe_fundraisers", JSON.stringify(fundraisers));
  }, [fundraisers]);

  const handleCreateFundraiser = (newFundraiser: Omit<Fundraiser, "id" | "raised" | "supporters" | "createdAt">) => {
    const fundraiser: Fundraiser = {
      ...newFundraiser,
      id: `fr${Date.now()}`,
      raised: 0,
      supporters: 0,
      createdAt: new Date().toISOString()
    };
    
    setFundraisers(prev => [fundraiser, ...prev]);
  };

  const handleDonate = (fundraiser: Fundraiser) => {
    setSelectedFundraiser(fundraiser);
    setShowDonate(true);
  };

  const handleDonationSuccess = (paymentData: { id: string; method: string }) => {
    if (!selectedFundraiser) return;
    
    // Update the fundraiser with the new donation
    const updatedFundraisers = fundraisers.map(f => {
      if (f.id === selectedFundraiser.id) {
        return {
          ...f,
          raised: f.raised + donationAmount / 100,
          supporters: f.supporters + 1
        };
      }
      return f;
    });
    
    setFundraisers(updatedFundraisers);
    setShowDonate(false);
    setSelectedFundraiser(null);
  };

  const handleCancelDonation = () => {
    setShowDonate(false);
    setSelectedFundraiser(null);
  };

  const isAuthenticated = !!currentUser;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Inmate Support Fundraisers</h2>
          <p className="text-muted-foreground">Help bless inmates and their families</p>
        </div>
        
        {isAuthenticated ? (
          <CreateFundraiserDialog onCreate={handleCreateFundraiser} />
        ) : (
          <Button disabled className="flex items-center gap-2">
            <LockIcon className="h-4 w-4" />
            Login to Create
          </Button>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {fundraisers.map((fundraiser) => (
          <FundraiserCard 
            key={fundraiser.id} 
            fundraiser={fundraiser}
            onDonate={handleDonate}
          />
        ))}
      </div>
      
      {/* Donation Dialog */}
      {showDonate && selectedFundraiser && (
        <Dialog open={showDonate} onOpenChange={setShowDonate}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Donate to: {selectedFundraiser.title}</DialogTitle>
            </DialogHeader>
            
            <div className="py-4">
              <div className="flex items-center gap-3 mb-6">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={selectedFundraiser.inmateImage || `https://api.dicebear.com/7.x/initials/svg?seed=${selectedFundraiser.inmateName}`} />
                  <AvatarFallback>{selectedFundraiser.inmateName.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{selectedFundraiser.inmateName}</p>
                  <p className="text-sm text-muted-foreground">{selectedFundraiser.inmateLocation}</p>
                </div>
              </div>
              
              <div className="mb-6 space-y-3">
                <label className="text-sm font-medium">Donation Amount</label>
                <div className="grid grid-cols-3 gap-2">
                  {[500, 1000, 2000, 5000, 10000, 20000].map((amount) => (
                    <Button
                      key={amount}
                      type="button"
                      variant={donationAmount === amount ? "default" : "outline"}
                      onClick={() => setDonationAmount(amount)}
                      className={donationAmount === amount ? "bg-violet-600" : ""}
                    >
                      ${(amount / 100).toFixed(2)}
                    </Button>
                  ))}
                </div>
              </div>
              
              <PaymentInterface 
                amount={donationAmount}
                description={`Donation to ${selectedFundraiser.title}`}
                onSuccess={handleDonationSuccess}
                onCancel={handleCancelDonation}
              />
            </div>
          </DialogContent>
        </Dialog>
      )}
      
      <div className="flex justify-center mt-8">
        <Button variant="outline" className="flex items-center gap-2">
          View More Fundraisers
          <ArrowRightIcon className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}