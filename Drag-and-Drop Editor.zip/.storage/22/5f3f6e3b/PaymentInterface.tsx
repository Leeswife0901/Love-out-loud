import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PaymentMethod, PaymentConfig } from "@/types";
import PaymentMethodSelector from "./PaymentMethodSelector";
import StripePaymentForm from "./StripePaymentForm";
import PayPalPaymentForm from "./PayPalPaymentForm";
import CashAppPaymentForm from "./CashAppPaymentForm";
import VenmoPaymentForm from "./VenmoPaymentForm";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";

// Mock Stripe promise for demo - in production, use your actual publishable key
const stripePromise = loadStripe("pk_test_TYooMQauvdEDq54NiTphI7jx");

interface PaymentInterfaceProps {
  amount: number;
  description: string;
  onSuccess: (paymentData: { id: string; method: string }) => void;
  onCancel: () => void;
}

export default function PaymentInterface({ 
  amount,
  description,
  onSuccess,
  onCancel 
}: PaymentInterfaceProps) {
  const { currentUser } = useAuth();
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>({
    id: "stripe",
    name: "Credit/Debit Card",
    icon: "fa-credit-card",
    description: "Pay securely with your credit or debit card",
    isActive: true,
  });
  const [processingPayment, setProcessingPayment] = useState(false);

  const handlePaymentSuccess = (paymentId: string) => {
    // Update user status in localStorage
    if (currentUser) {
      const updatedUser = {
        ...currentUser,
        hasPaid: true
      };
      localStorage.setItem("urbanvibe_user", JSON.stringify(updatedUser));
    }
    
    // Show success message
    toast.success("Payment processed successfully!");
    
    // Call the onSuccess callback with payment details
    onSuccess({ 
      id: paymentId,
      method: selectedMethod.id
    });
  };

  const handlePaymentError = (error: string) => {
    toast.error(`Payment failed: ${error}`);
    setProcessingPayment(false);
  };

  const renderPaymentForm = () => {
    switch (selectedMethod.id) {
      case "stripe":
        return (
          <Elements stripe={stripePromise}>
            <StripePaymentForm 
              amount={amount} 
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
            />
          </Elements>
        );
      case "paypal":
        return (
          <PayPalPaymentForm 
            amount={amount}
            onSuccess={handlePaymentSuccess}
            onError={handlePaymentError}
          />
        );
      case "cashapp":
        return (
          <CashAppPaymentForm 
            amount={amount}
            onSuccess={handlePaymentSuccess}
            onError={handlePaymentError}
          />
        );
      case "venmo":
        return (
          <VenmoPaymentForm 
            amount={amount}
            onSuccess={handlePaymentSuccess}
            onError={handlePaymentError}
          />
        );
      default:
        return (
          <div className="p-4 text-center">
            Please select a payment method
          </div>
        );
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Payment Details</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-baseline justify-between">
          <div className="text-sm text-muted-foreground">Amount:</div>
          <div className="text-2xl font-bold">${(amount / 100).toFixed(2)}</div>
        </div>

        <PaymentMethodSelector onSelect={setSelectedMethod} />

        <div className="pt-4">
          {renderPaymentForm()}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between border-t pt-4">
        <button 
          className="text-sm text-muted-foreground hover:underline"
          onClick={onCancel}
          disabled={processingPayment}
        >
          Cancel
        </button>
      </CardFooter>
    </Card>
  );
}