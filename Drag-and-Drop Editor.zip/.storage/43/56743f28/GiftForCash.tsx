import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  GiftIcon,
  SearchIcon,
  HeartIcon,
  CakeIcon,
  FlowerIcon,
  StarIcon,
  MusicIcon,
  PartyPopperIcon,
  BadgeCheck,
  UserIcon
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import PaymentInterface from "@/components/payments/PaymentInterface";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

interface Gift {
  id: string;
  name: string;
  icon: React.ReactNode;
  price: number;
  cashValue: number;
  description: string;
}

interface User {
  id: string;
  username: string;
  displayName?: string;
  avatar?: string;
  bio?: string;
  isVerified?: boolean;
}

export default function GiftForCash() {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState("browse");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGift, setSelectedGift] = useState<Gift | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [personalMessage, setPersonalMessage] = useState("");
  const [showPaymentForm, setShowPaymentForm] = useState(false);

  const availableGifts: Gift[] = [
    {
      id: "gift1",
      name: "Love Boost",
      icon: <HeartIcon className="h-5 w-5 text-pink-600" />,
      price: 5,
      cashValue: 4,
      description: "Send love and positive energy to brighten someone's day."
    },
    {
      id: "gift2",
      name: "Birthday Cake",
      icon: <CakeIcon className="h-5 w-5 text-purple-600" />,
      price: 10,
      cashValue: 8,
      description: "Celebrate a birthday or special occasion with a virtual cake."
    },
    {
      id: "gift3",
      name: "Rose Bouquet",
      icon: <FlowerIcon className="h-5 w-5 text-red-600" />,
      price: 20,
      cashValue: 16,
      description: "Express your affection with a beautiful bouquet of roses."
    },
    {
      id: "gift4",
      name: "VIP Star",
      icon: <StarIcon className="h-5 w-5 text-yellow-600" />,
      price: 50,
      cashValue: 42,
      description: "Give VIP treatment with this premium gift that stands out."
    },
    {
      id: "gift5",
      name: "Music Token",
      icon: <MusicIcon className="h-5 w-5 text-blue-600" />,
      price: 15,
      cashValue: 12,
      description: "Help support their music or creative projects."
    },
    {
      id: "gift6",
      name: "Celebration Pack",
      icon: <PartyPopperIcon className="h-5 w-5 text-violet-600" />,
      price: 25,
      cashValue: 20,
      description: "A full celebration package to mark a major milestone."
    }
  ];

  // Mock users list - in a real app, this would come from an API
  const users = [
    {
      id: "user1",
      username: "melody_queen",
      displayName: "Melody Queen",
      avatar: "https://api.dicebear.com/7.x/micah/svg?seed=melody_queen",
      bio: "Music artist and creative soul.",
      isVerified: true
    },
    {
      id: "user2",
      username: "urban_creator",
      displayName: "Urban Creator",
      avatar: "https://api.dicebear.com/7.x/micah/svg?seed=urban_creator",
      bio: "Visual artist and beat maker.",
      isVerified: true
    },
    {
      id: "user3",
      username: "resilient87",
      displayName: "Marcus J.",
      avatar: "https://api.dicebear.com/7.x/micah/svg?seed=resilient87",
      bio: "Building a new start. Your support helps me rebuild.",
      isVerified: false
    },
    {
      id: "user4",
      username: "new_chapter",
      displayName: "Alisha Williams",
      avatar: "https://api.dicebear.com/7.x/micah/svg?seed=new_chapter",
      bio: "Author and speaker. Sharing my journey after incarceration.",
      isVerified: true
    },
    {
      id: "user5",
      username: "hopeful_minds",
      displayName: "Hope Foundation",
      avatar: "https://api.dicebear.com/7.x/micah/svg?seed=hopeful_minds",
      bio: "Supporting rehabilitation and reintegration programs.",
      isVerified: true
    }
  ];

  const filteredUsers = users.filter(user => 
    user.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (user.displayName && user.displayName.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleSelectGift = (gift: Gift) => {
    setSelectedGift(gift);
    setActiveTab("recipient");
  };

  const handleSelectUser = (user: User) => {
    setSelectedUser(user);
    setActiveTab("message");
  };

  const handleBack = () => {
    if (activeTab === "recipient") {
      setActiveTab("browse");
      setSelectedGift(null);
    } else if (activeTab === "message") {
      setActiveTab("recipient");
      setSelectedUser(null);
      setPersonalMessage("");
    } else if (activeTab === "payment") {
      setActiveTab("message");
      setShowPaymentForm(false);
    }
  };

  const handleSubmit = () => {
    if (!selectedGift || !selectedUser) return;
    
    setActiveTab("payment");
    setShowPaymentForm(true);
  };

  const handlePaymentComplete = (paymentMethod: string, paymentId: string) => {
    // In a real app, this would process the payment through the backend
    // For demo purposes, we'll just show a success message
    
    if (!selectedGift || !selectedUser) return;
    
    // Create gift record in localStorage for demo
    const newGift = {
      id: `gift_${Date.now()}`,
      giftId: selectedGift.id,
      giftName: selectedGift.name,
      senderId: currentUser?.id,
      senderName: currentUser?.username,
      recipientId: selectedUser.id,
      recipientName: selectedUser.username,
      price: selectedGift.price,
      cashValue: selectedGift.cashValue,
      message: personalMessage,
      timestamp: new Date().toISOString(),
      paymentMethod,
      paymentId
    };
    
    // Store in localStorage for demo
    const storedGifts = localStorage.getItem("loveoutloud_gifts");
    const gifts = storedGifts ? JSON.parse(storedGifts) : [];
    gifts.push(newGift);
    localStorage.setItem("loveoutloud_gifts", JSON.stringify(gifts));
    
    // Reset state
    setSelectedGift(null);
    setSelectedUser(null);
    setPersonalMessage("");
    setShowPaymentForm(false);
    
    toast.success(`Gift sent successfully! ${selectedUser.displayName || selectedUser.username} will receive $${selectedGift.cashValue} in cash.`);
    setActiveTab("browse");
  };

  function GiftCard({ gift, onSelect }: { gift: Gift, onSelect: (gift: Gift) => void }) {
    return (
      <Card 
        className="cursor-pointer hover:shadow-md transition-all" 
        onClick={() => onSelect(gift)}
      >
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">{gift.name}</CardTitle>
            <div className="h-12 w-12 rounded-full bg-violet-50 dark:bg-gray-800 flex items-center justify-center">
              {gift.icon}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            {gift.description}
          </p>
          <div className="flex items-center justify-between">
            <Badge variant="outline" className="bg-violet-50 text-violet-700 dark:bg-violet-950 dark:text-violet-300">
              ${gift.price}
            </Badge>
            <span className="text-sm text-muted-foreground">
              ${gift.cashValue} cash value
            </span>
          </div>
        </CardContent>
      </Card>
    );
  }

  function UserCard({ user, onSelect }: { user: User, onSelect: (user: User) => void }) {
    return (
      <Card 
        className="cursor-pointer hover:shadow-md transition-all" 
        onClick={() => onSelect(user)}
      >
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage src={user.avatar || `https://api.dicebear.com/7.x/micah/svg?seed=${user.username}`} />
              <AvatarFallback>{user.displayName?.charAt(0) || user.username.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-1">
                <h4 className="font-medium">{user.displayName || user.username}</h4>
                {user.isVerified && <BadgeCheck className="h-4 w-4 text-violet-600" />}
              </div>
              <p className="text-muted-foreground text-sm">@{user.username}</p>
            </div>
          </div>
          {user.bio && (
            <p className="text-sm mt-2 line-clamp-2">{user.bio}</p>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Send Gifts</h1>
        <p className="text-muted-foreground mt-1">
          Send virtual gifts that convert to real cash for your loved ones
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4">
          <TabsTrigger value="browse">1. Choose Gift</TabsTrigger>
          <TabsTrigger value="recipient" disabled={!selectedGift && activeTab !== "recipient"}>
            2. Recipient
          </TabsTrigger>
          <TabsTrigger value="message" disabled={!selectedUser && activeTab !== "message"}>
            3. Message
          </TabsTrigger>
          <TabsTrigger value="payment" disabled={activeTab !== "payment"}>
            4. Payment
          </TabsTrigger>
        </TabsList>

        {/* Step 1: Browse Gifts */}
        <TabsContent value="browse" className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {availableGifts.map(gift => (
              <GiftCard
                key={gift.id}
                gift={gift}
                onSelect={handleSelectGift}
              />
            ))}
          </div>
        </TabsContent>

        {/* Step 2: Choose Recipient */}
        <TabsContent value="recipient" className="pt-6">
          {selectedGift && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Selected Gift:</h3>
                <Badge className="bg-violet-600 hover:bg-violet-700 flex items-center gap-2">
                  {selectedGift.icon}
                  <span>{selectedGift.name} - ${selectedGift.price}</span>
                </Badge>
              </div>
              
              <div className="space-y-4">
                <div className="relative">
                  <SearchIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search for a user..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredUsers.map(user => (
                    <UserCard
                      key={user.id}
                      user={user}
                      onSelect={handleSelectUser}
                    />
                  ))}
                  
                  {filteredUsers.length === 0 && (
                    <div className="col-span-full text-center py-8">
                      <UserIcon className="h-12 w-12 mx-auto text-muted-foreground opacity-40" />
                      <p className="mt-3">No users match your search</p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={handleBack}>
                  Back to Gifts
                </Button>
              </div>
            </div>
          )}
        </TabsContent>

        {/* Step 3: Add Message */}
        <TabsContent value="message" className="pt-6">
          {selectedGift && selectedUser && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <GiftIcon className="h-5 w-5 text-violet-600" />
                    Gift Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">Gift</p>
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-violet-50 dark:bg-gray-800 flex items-center justify-center">
                            {selectedGift.icon}
                          </div>
                          <div>
                            <p className="font-medium">{selectedGift.name}</p>
                            <p className="text-xs text-muted-foreground">${selectedGift.cashValue} cash value</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">To</p>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={selectedUser.avatar || `https://api.dicebear.com/7.x/micah/svg?seed=${selectedUser.username}`} />
                            <AvatarFallback>{selectedUser.displayName?.charAt(0) || selectedUser.username.charAt(0).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <p className="font-medium">{selectedUser.displayName || selectedUser.username}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="message">Add a personal message</Label>
                      <Textarea
                        id="message"
                        placeholder="Write something nice..."
                        value={personalMessage}
                        onChange={(e) => setPersonalMessage(e.target.value)}
                        className="min-h-[100px]"
                      />
                    </div>
                    
                    <div className="bg-violet-50 dark:bg-gray-800 p-4 rounded-lg">
                      <div className="flex items-start gap-3">
                        <HeartIcon className="h-5 w-5 text-violet-600 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium">How this works</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            When you send this gift, {selectedUser.displayName || selectedUser.username} will 
                            receive ${selectedGift.cashValue} in cash (80% of your purchase) deposited to their 
                            account. The remaining amount helps maintain our platform.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between pt-4">
                  <Button variant="outline" onClick={handleBack}>
                    Back
                  </Button>
                  <Button 
                    onClick={handleSubmit}
                    className="bg-violet-600 hover:bg-violet-700"
                  >
                    Continue to Payment
                  </Button>
                </CardFooter>
              </Card>
            </div>
          )}
        </TabsContent>

        {/* Step 4: Payment */}
        <TabsContent value="payment" className="pt-6">
          {selectedGift && selectedUser && showPaymentForm && (
            <Card>
              <CardHeader>
                <CardTitle>Complete your gift</CardTitle>
                <CardDescription>
                  You're sending a {selectedGift.name} to {selectedUser.displayName || selectedUser.username}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PaymentInterface 
                  amount={selectedGift.price}
                  onPaymentComplete={handlePaymentComplete}
                  description={`Gift: ${selectedGift.name} for @${selectedUser.username}`}
                />
              </CardContent>
              <CardFooter className="flex justify-start pt-4">
                <Button variant="outline" onClick={handleBack}>
                  Back
                </Button>
              </CardFooter>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}