import { useState } from "react";
import { PaymentMethod } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface PaymentMethodSelectorProps {
  onSelect: (method: PaymentMethod) => void;
}

export default function PaymentMethodSelector({ onSelect }: PaymentMethodSelectorProps) {
  const paymentMethods: PaymentMethod[] = [
    {
      id: "stripe",
      name: "Credit/Debit Card",
      icon: "fa-credit-card",
      description: "Pay securely with your credit or debit card",
      isActive: true,
    },
    {
      id: "paypal",
      name: "PayPal",
      icon: "fa-paypal",
      description: "Pay with your PayPal account",
      isActive: false,
    },
    {
      id: "cashapp",
      name: "Cash App",
      icon: "fa-dollar-sign",
      description: "Pay with Cash App",
      isActive: false,
    },
    {
      id: "venmo",
      name: "Venmo",
      icon: "fa-v",
      description: "Pay with Venmo",
      isActive: false,
    },
  ];

  const [selectedMethod, setSelectedMethod] = useState<string>("stripe");

  const handleMethodChange = (value: string) => {
    setSelectedMethod(value);
    const method = paymentMethods.find((m) => m.id === value);
    if (method) {
      onSelect({ ...method, isActive: true });
    }
  };

  return (
    <div className="w-full">
      <h3 className="text-lg font-semibold mb-4">Select Payment Method</h3>
      <RadioGroup value={selectedMethod} onValueChange={handleMethodChange} className="space-y-3">
        {paymentMethods.map((method) => (
          <div
            key={method.id}
            className={`payment-method-card flex items-center ${
              selectedMethod === method.id ? "active" : ""
            }`}
          >
            <RadioGroupItem value={method.id} id={method.id} className="mr-4" />
            <Label htmlFor={method.id} className="flex items-center cursor-pointer flex-1">
              <i className={`fas ${method.icon} text-lg mr-3 text-violet-600`}></i>
              <div>
                <h4 className="text-sm font-medium">{method.name}</h4>
                <p className="text-xs text-gray-500">{method.description}</p>
              </div>
            </Label>
          </div>
        ))}
      </RadioGroup>
    </div>
  );
}