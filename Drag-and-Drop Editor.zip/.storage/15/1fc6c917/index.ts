export interface User {
  id: string;
  username: string;
  email: string;
  avatar?: string;
  bio?: string;
  followers: number;
  following: number;
  hasPaid: boolean;
  joinedDate: string;
}

export interface Post {
  id: string;
  userId: string;
  username: string;
  userAvatar?: string;
  content: string;
  mediaUrl?: string;
  likes: number;
  comments: number;
  timestamp: string;
  isPremium?: boolean;
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  username: string;
  userAvatar?: string;
  content: string;
  timestamp: string;
  likes: number;
}

export interface PaymentMethod {
  id: string;
  name: string;
  icon: string;
  description: string;
  isActive: boolean;
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: string;
  metadata?: Record<string, string>;
  created: string;
  paymentMethod: string;
}

export type PaymentProvider = 'stripe' | 'paypal' | 'cashapp' | 'venmo';

export interface PaymentConfig {
  provider: PaymentProvider;
  amount: number;
  currency: string;
  description: string;
  metadata?: Record<string, string>;
}