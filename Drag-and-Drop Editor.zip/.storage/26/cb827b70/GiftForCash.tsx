import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { GiftIcon, DollarSignIcon, SendIcon, StarIcon } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import PaymentInterface from "../payments/PaymentInterface";

interface Gift {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  popularity: number;
}

interface GiftCardProps {
  gift: Gift;
  onSend: (gift: Gift) => void;
}

function GiftCard({ gift, onSend }: GiftCardProps) {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-md">
      <div className="aspect-square bg-gray-100 overflow-hidden">
        <img 
          src={gift.image}
          alt={gift.name}
          className="w-full h-full object-cover"
        />
      </div>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-medium">{gift.name}</h3>
          <span className="font-bold text-violet-600">${(gift.price / 100).toFixed(2)}</span>
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{gift.description}</p>
        <div className="flex items-center text-amber-500">
          {Array(5).fill(0).map((_, i) => (
            <StarIcon 
              key={i} 
              className={`h-3 w-3 ${i < gift.popularity ? 'fill-current' : 'opacity-30'}`} 
            />
          ))}
        </div>
      </CardContent>
      <CardFooter className="p-3 pt-0">
        <Button 
          onClick={() => onSend(gift)}
          className="w-full" 
          size="sm"
          variant="outline"
        >
          <GiftIcon className="h-4 w-4 mr-2" />
          Send Gift
        </Button>
      </CardFooter>
    </Card>
  );
}

interface SendGiftDialogProps {
  gift: Gift;
  onClose: () => void;
  onSend: (username: string, message: string, gift: Gift) => void;
}

function SendGiftDialog({ gift, onClose, onSend }: SendGiftDialogProps) {
  const [username, setUsername] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSend(username, message, gift);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <div className="h-16 w-16 overflow-hidden rounded-md">
          <img 
            src={gift.image}
            alt={gift.name}
            className="h-full w-full object-cover"
          />
        </div>
        <div>
          <h3 className="font-medium">{gift.name}</h3>
          <p className="text-sm text-muted-foreground">{gift.description}</p>
          <p className="text-violet-600 font-bold mt-1">${(gift.price / 100).toFixed(2)}</p>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="username">Recipient's Username</Label>
          <Input
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="@username"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="message">Message (optional)</Label>
          <Input
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Add a message..."
          />
        </div>
        
        <div className="pt-2 flex justify-between">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" className="bg-violet-600 hover:bg-violet-700">
            <SendIcon className="h-4 w-4 mr-2" />
            Continue to Payment
          </Button>
        </div>
      </form>
    </div>
  );
}

export default function GiftForCash() {
  const { currentUser } = useAuth();
  const [activeCategory, setActiveCategory] = useState("popular");
  const [selectedGift, setSelectedGift] = useState<Gift | null>(null);
  const [showSendDialog, setShowSendDialog] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [recipient, setRecipient] = useState("");
  const [message, setMessage] = useState("");

  // Sample gift data - in a real app, this would come from an API
  const gifts: Record<string, Gift[]> = {
    popular: [
      {
        id: "gift1",
        name: "Premium Beats",
        description: "Exclusive beat tracks from top urban producers",
        price: 1500,
        image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop",
        category: "music",
        popularity: 5
      },
      {
        id: "gift2",
        name: "Virtual Roses",
        description: "Show your affection with a bouquet of virtual roses",
        price: 500,
        image: "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=800&auto=format&fit=crop",
        category: "virtual",
        popularity: 4
      },
      {
        id: "gift3",
        name: "VIP Status (1 week)",
        description: "Give someone VIP status for one week",
        price: 2000,
        image: "https://images.unsplash.com/photo-1527689368864-3a821dbccc34?w=800&auto=format&fit=crop",
        category: "status",
        popularity: 5
      }
    ],
    virtual: [
      {
        id: "gift4",
        name: "Virtual High Five",
        description: "A simple gesture to show support",
        price: 100,
        image: "https://images.unsplash.com/photo-1535899200886-4c9babb66a22?w=800&auto=format&fit=crop",
        category: "virtual",
        popularity: 3
      },
      {
        id: "gift5",
        name: "Digital Crown",
        description: "Crown someone as royalty for a day",
        price: 1000,
        image: "https://images.unsplash.com/photo-1589411454940-67a017535ecf?w=800&auto=format&fit=crop",
        category: "virtual",
        popularity: 4
      }
    ],
    music: [
      {
        id: "gift6",
        name: "Exclusive Track",
        description: "Unreleased tracks from underground artists",
        price: 1200,
        image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop",
        category: "music",
        popularity: 4
      },
      {
        id: "gift7",
        name: "Shoutout Token",
        description: "Get a personalized shoutout in an upcoming track",
        price: 5000,
        image: "https://images.unsplash.com/photo-1516981879613-9f5da904015f?w=800&auto=format&fit=crop",
        category: "music",
        popularity: 5
      }
    ],
    status: [
      {
        id: "gift8",
        name: "Verified Badge (3 days)",
        description: "Temporary verified status on the platform",
        price: 3000,
        image: "https://images.unsplash.com/photo-1566183629939-54456a258896?w=800&auto=format&fit=crop",
        category: "status",
        popularity: 5
      }
    ]
  };

  const handleSendGift = (gift: Gift) => {
    setSelectedGift(gift);
    setShowSendDialog(true);
  };

  const handleDialogClose = () => {
    setSelectedGift(null);
    setShowSendDialog(false);
  };

  const handleContinueToPayment = (username: string, giftMessage: string, gift: Gift) => {
    setRecipient(username);
    setMessage(giftMessage);
    setShowSendDialog(false);
    setShowPayment(true);
  };

  const handlePaymentSuccess = (paymentData: { id: string; method: string }) => {
    if (!selectedGift || !recipient) return;
    
    // Store gift transaction in localStorage
    const giftTx = {
      id: `gift_tx_${Date.now()}`,
      paymentId: paymentData.id,
      paymentMethod: paymentData.method,
      giftId: selectedGift.id,
      giftName: selectedGift.name,
      giftPrice: selectedGift.price,
      senderId: currentUser?.id || "guest",
      senderName: currentUser?.username || "guest",
      recipientName: recipient,
      message: message || "",
      timestamp: new Date().toISOString()
    };
    
    const giftTxs = JSON.parse(localStorage.getItem("urbanvibe_gift_transactions") || "[]");
    giftTxs.unshift(giftTx);
    localStorage.setItem("urbanvibe_gift_transactions", JSON.stringify(giftTxs));
    
    toast.success(`Gift sent to ${recipient}!`);
    
    setSelectedGift(null);
    setRecipient("");
    setMessage("");
    setShowPayment(false);
  };

  const handleCancelPayment = () => {
    setShowPayment(false);
  };

  const isAuthenticated = !!currentUser;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Gift for Cash</h2>
        <p className="text-muted-foreground">Send virtual gifts that convert to real money</p>
      </div>
      
      <Tabs defaultValue="popular" value={activeCategory} onValueChange={setActiveCategory}>
        <TabsList>
          <TabsTrigger value="popular">Popular</TabsTrigger>
          <TabsTrigger value="virtual">Virtual Items</TabsTrigger>
          <TabsTrigger value="music">Music</TabsTrigger>
          <TabsTrigger value="status">Status</TabsTrigger>
        </TabsList>
        
        {Object.entries(gifts).map(([category, categoryGifts]) => (
          <TabsContent key={category} value={category}>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {categoryGifts.map((gift) => (
                <GiftCard 
                  key={gift.id} 
                  gift={gift}
                  onSend={handleSendGift}
                />
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
      
      {/* Send Gift Dialog */}
      <Dialog open={showSendDialog} onOpenChange={setShowSendDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Send Gift</DialogTitle>
          </DialogHeader>
          {selectedGift && (
            <SendGiftDialog
              gift={selectedGift}
              onClose={handleDialogClose}
              onSend={handleContinueToPayment}
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Payment Dialog */}
      <Dialog open={showPayment} onOpenChange={setShowPayment}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Complete Payment</DialogTitle>
          </DialogHeader>
          {selectedGift && (
            <PaymentInterface 
              amount={selectedGift.price}
              description={`Gift: ${selectedGift.name} for @${recipient}`}
              onSuccess={handlePaymentSuccess}
              onCancel={handleCancelPayment}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}