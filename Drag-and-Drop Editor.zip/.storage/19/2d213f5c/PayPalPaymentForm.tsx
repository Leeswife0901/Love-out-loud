import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/context/AuthContext";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";

interface PayPalPaymentFormProps {
  amount: number;
  onSuccess: (paymentId: string) => void;
  onError: (error: string) => void;
}

export default function PayPalPaymentForm({ amount, onSuccess, onError }: PayPalPaymentFormProps) {
  const [error, setError] = useState<string | null>(null);
  const { currentUser } = useAuth();
  const amountInDollars = (amount / 100).toFixed(2);
  const [isProcessing, setIsProcessing] = useState(false);

  const initialOptions = {
    "client-id": "test",
    currency: "USD",
    intent: "capture",
  };

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <PayPalScriptProvider options={initialOptions}>
        <div className="flex justify-center p-4 border rounded-md bg-gray-50 dark:bg-gray-800">
          <PayPalButtons
            disabled={isProcessing}
            createOrder={async () => {
              try {
                setIsProcessing(true);
                const response = await fetch("/api/create-paypal-order", {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                    amount,
                    userId: currentUser?.id || "guest",
                    username: currentUser?.username || "guest"
                  }),
                });
                
                const data = await response.json();
                
                if (data.error) {
                  throw new Error(data.error);
                }
                
                return data.orderId;
              } catch (err) {
                const errorMessage = err instanceof Error ? err.message : "Failed to create PayPal order";
                setError(errorMessage);
                onError(errorMessage);
                setIsProcessing(false);
                throw err;
              }
            }}
            onApprove={async (data) => {
              try {
                const response = await fetch("/api/capture-paypal-order", {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                    orderID: data.orderID,
                  }),
                });
                
                const captureData = await response.json();
                
                if (captureData.error) {
                  throw new Error(captureData.error);
                }
                
                onSuccess(data.orderID);
              } catch (err) {
                const errorMessage = err instanceof Error ? err.message : "Failed to process PayPal payment";
                setError(errorMessage);
                onError(errorMessage);
              } finally {
                setIsProcessing(false);
              }
            }}
            onError={(err) => {
              const errorMessage = err instanceof Error ? err.message : "PayPal payment error";
              setError(errorMessage);
              onError(errorMessage);
              setIsProcessing(false);
            }}
            style={{ layout: "horizontal" }}
          />
        </div>
      </PayPalScriptProvider>

      <div className="text-center text-sm text-gray-500">
        <p>Secure payment processed by PayPal</p>
      </div>
    </div>
  );
}