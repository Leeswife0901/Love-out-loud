import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { VideoIcon, CheckCircleIcon, AlertCircleIcon } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { Progress } from "@/components/ui/progress";

interface StreakTrackerProps {
  onCreateDailyPost: () => void;
}

interface Streak {
  count: number;
  lastPosted: string;
  history: { date: string; completed: boolean }[];
}

export default function StreakTracker({ onCreateDailyPost }: StreakTrackerProps) {
  const { currentUser } = useAuth();
  const [streak, setStreak] = useState<Streak>({
    count: 0,
    lastPosted: "",
    history: []
  });
  const [hasPostedToday, setHasPostedToday] = useState(false);
  const [timeLeft, setTimeLeft] = useState("");
  
  useEffect(() => {
    if (currentUser) {
      // In a real app, fetch streak data from API
      // For demo, we'll use localStorage
      const storedStreak = localStorage.getItem(`streak_${currentUser.id}`);
      
      if (storedStreak) {
        const parsedStreak = JSON.parse(storedStreak);
        setStreak(parsedStreak);
        
        // Check if user has posted today
        const today = new Date().toISOString().split('T')[0];
        const lastPosted = new Date(parsedStreak.lastPosted).toISOString().split('T')[0];
        setHasPostedToday(today === lastPosted);
      }
    }
  }, [currentUser]);
  
  useEffect(() => {
    // Update time left
    const updateTimeLeft = () => {
      const now = new Date();
      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);
      
      const diff = endOfDay.getTime() - now.getTime();
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      
      setTimeLeft(`${hours}h ${minutes}m`);
    };
    
    updateTimeLeft();
    const interval = setInterval(updateTimeLeft, 60000); // Update every minute
    
    return () => clearInterval(interval);
  }, []);

  if (!currentUser) {
    return null;
  }

  // Calculate streaks percentage for today
  const hoursElapsed = new Date().getHours();
  const dayPercentComplete = Math.min(100, Math.round((hoursElapsed / 24) * 100));

  return (
    <div className="bg-gradient-to-r from-violet-50 to-purple-50 dark:from-gray-800 dark:to-gray-900 rounded-lg p-4 border border-violet-100 dark:border-gray-700">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-medium text-lg flex items-center">
            <span className="mr-2 text-violet-700">🔥</span> 
            Your Streak: <span className="text-violet-700 font-bold ml-1">{streak.count} days</span>
          </h3>
          <p className="text-sm text-muted-foreground">
            {hasPostedToday 
              ? "You've posted today! Keep the streak going!"
              : `${timeLeft} left to post today`}
          </p>
        </div>
        
        {!hasPostedToday && (
          <Button 
            onClick={onCreateDailyPost}
            className="bg-violet-600 hover:bg-violet-700"
          >
            <VideoIcon className="h-4 w-4 mr-2" />
            Post Now
          </Button>
        )}
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span>Today's Progress</span>
          <span>{hasPostedToday ? "Completed!" : `${dayPercentComplete}%`}</span>
        </div>
        <Progress value={hasPostedToday ? 100 : dayPercentComplete} className="h-2" />
      </div>
      
      <div className="mt-4 flex">
        {/* Display the last 5 days */}
        {Array(7).fill(0).map((_, i) => {
          // In a real app, we'd use the actual streak history
          // For demo, we'll show a random pattern with today incomplete if hasPostedToday is false
          const isToday = i === 6;
          const isComplete = isToday ? hasPostedToday : Math.random() > 0.3;
          
          return (
            <div key={i} className="flex-1 flex flex-col items-center px-1">
              <div className={`w-full aspect-square rounded-full flex items-center justify-center 
                ${isComplete 
                  ? 'bg-violet-100 text-violet-700 dark:bg-violet-900 dark:text-violet-300' 
                  : 'bg-gray-100 text-gray-400 dark:bg-gray-800 dark:text-gray-500'}`}
              >
                {isComplete 
                  ? <CheckCircleIcon className="h-4 w-4" /> 
                  : <AlertCircleIcon className="h-4 w-4" />}
              </div>
              <span className="text-xs mt-1">
                {isToday ? 'Today' : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][(new Date().getDay() + i) % 7]}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}