import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CalendarIcon, VideoIcon, FlameIcon } from "lucide-react";

interface StreakTrackerProps {
  onCreateDailyPost: () => void;
}

export default function StreakTracker({ onCreateDailyPost }: StreakTrackerProps) {
  const { currentUser } = useAuth();
  const [streakData, setStreakData] = useState({
    currentStreak: 0,
    longestStreak: 0,
    lastPostDate: null as string | null,
    hasPostedToday: false
  });

  useEffect(() => {
    // Load streak data from localStorage
    const loadStreakData = () => {
      if (!currentUser?.id) return;
      
      const storedData = localStorage.getItem(`urbanvibe_streak_${currentUser.id}`);
      if (storedData) {
        const data = JSON.parse(storedData);
        
        // Check if user has posted today
        const today = new Date().toISOString().split('T')[0];
        const hasPostedToday = data.lastPostDate === today;
        
        // Check if streak is broken (more than 1 day since last post)
        const lastPostDate = data.lastPostDate ? new Date(data.lastPostDate) : null;
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        
        let currentStreak = data.currentStreak;
        
        if (lastPostDate) {
          const daysSinceLastPost = Math.floor((new Date().getTime() - lastPostDate.getTime()) / (1000 * 3600 * 24));
          
          if (daysSinceLastPost > 1) {
            // Streak broken
            currentStreak = hasPostedToday ? 1 : 0;
          }
        }
        
        setStreakData({
          currentStreak,
          longestStreak: data.longestStreak,
          lastPostDate: data.lastPostDate,
          hasPostedToday
        });
      }
    };
    
    loadStreakData();
  }, [currentUser?.id]);

  // Function to update streak when user posts
  const updateStreak = () => {
    if (!currentUser?.id) return;
    
    const today = new Date().toISOString().split('T')[0];
    const updatedStreak = streakData.hasPostedToday ? 
      streakData.currentStreak : 
      streakData.currentStreak + 1;
      
    const updatedLongestStreak = Math.max(updatedStreak, streakData.longestStreak);
    
    const newStreakData = {
      currentStreak: updatedStreak,
      longestStreak: updatedLongestStreak,
      lastPostDate: today,
      hasPostedToday: true
    };
    
    // Save to localStorage
    localStorage.setItem(
      `urbanvibe_streak_${currentUser.id}`, 
      JSON.stringify(newStreakData)
    );
    
    setStreakData(newStreakData);
  };

  const handleCreateDailyPost = () => {
    onCreateDailyPost();
    updateStreak();
  };

  return (
    <div className="p-4 border rounded-lg bg-gradient-to-r from-violet-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-lg flex items-center">
          <FlameIcon className="h-5 w-5 mr-2 text-orange-500" />
          Daily Journal Streak
        </h3>
        <Badge variant="outline" className="bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-100">
          {streakData.currentStreak} days
        </Badge>
      </div>
      
      <Progress
        value={(streakData.currentStreak % 7) * (100/7)}
        className="h-2 mb-3"
      />
      
      <div className="flex justify-between text-xs text-gray-500 mb-4">
        <span>Day {streakData.currentStreak % 7}/7</span>
        <span>Next milestone: {7 - (streakData.currentStreak % 7)} days</span>
      </div>
      
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <span className="text-sm">Longest streak</span>
          <span className="font-medium">{streakData.longestStreak} days</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm">Last journal</span>
          <span className="font-medium flex items-center">
            <CalendarIcon className="h-3 w-3 mr-1" />
            {streakData.lastPostDate ? new Date(streakData.lastPostDate).toLocaleDateString() : "Never"}
          </span>
        </div>
      </div>
      
      <button
        onClick={handleCreateDailyPost}
        disabled={streakData.hasPostedToday}
        className={`mt-4 w-full py-2 px-4 rounded-md flex items-center justify-center gap-2 ${
          streakData.hasPostedToday 
            ? "bg-gray-200 text-gray-500 cursor-not-allowed dark:bg-gray-700" 
            : "bg-gradient-to-r from-violet-600 to-indigo-600 text-white hover:from-violet-700 hover:to-indigo-700"
        }`}
      >
        <VideoIcon className="h-5 w-5" />
        {streakData.hasPostedToday ? "Journal Posted Today" : "Post Today's Journal"}
      </button>
    </div>
  );
}