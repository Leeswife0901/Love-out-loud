import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/context/AuthContext";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface VenmoPaymentFormProps {
  amount: number;
  onSuccess: (paymentId: string) => void;
  onError: (error: string) => void;
}

export default function VenmoPaymentForm({ amount, onSuccess, onError }: VenmoPaymentFormProps) {
  const [error, setError] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [venmoUsername, setVenmoUsername] = useState("");
  const { currentUser } = useAuth();
  const amountInDollars = (amount / 100).toFixed(2);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!venmoUsername) {
      setError("Please enter your Venmo username");
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      // In a real app, this would call the Venmo API
      // For now, we simulate a successful payment with a delay
      
      // Simulated API call
      const response = await fetch("/api/create-venmo-payment", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount,
          venmoUsername,
          userId: currentUser?.id || "guest",
          username: currentUser?.username || "guest"
        }),
      });
      
      const data = await response.json();
      
      if (!data.success) {
        throw new Error(data.message || "Payment failed");
      }

      // Simulate a delay for payment processing
      setTimeout(() => {
        onSuccess(`venmo_${Date.now()}`);
        setProcessing(false);
      }, 2000);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Payment processing failed";
      setError(errorMessage);
      onError(errorMessage);
      setProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="p-4 border rounded-md bg-gray-50 dark:bg-gray-800">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="venmo-username">Your Venmo Username</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-600 font-bold">@</span>
              <Input
                id="venmo-username"
                value={venmoUsername}
                onChange={(e) => setVenmoUsername(e.target.value)}
                className="pl-8"
                placeholder="YourVenmoUsername"
              />
            </div>
          </div>
          
          <div>
            <p className="text-sm text-gray-500">
              You'll be paying <span className="font-bold text-blue-600">${amountInDollars}</span> via Venmo
            </p>
          </div>
        </div>
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <Button 
        type="submit" 
        className="w-full bg-blue-500 hover:bg-blue-600 text-white"
        disabled={processing}
      >
        {processing ? "Processing..." : `Pay $${amountInDollars} with Venmo`}
      </Button>
      
      <div className="text-center text-sm text-gray-500">
        <p>This would open Venmo in a real implementation</p>
      </div>
    </form>
  );
}