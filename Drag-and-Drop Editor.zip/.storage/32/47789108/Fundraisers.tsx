import InmateFundraiser from "@/components/social/InmateFundraiser";

export default function Fundraisers() {
  return (
    <div className="container max-w-6xl px-4 py-6 mb-16 md:mb-0">
      <InmateFundraiser />
    </div>
  );
}