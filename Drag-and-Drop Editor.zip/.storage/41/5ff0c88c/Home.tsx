import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { HeartIcon, MessageCircleIcon, ShareIcon, PlayCircleIcon } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import StreakTracker from "@/components/social/StreakTracker";

interface Post {
  id: string;
  userId: string;
  username: string;
  userAvatar?: string;
  content: string;
  mediaUrl?: string;
  likes: number;
  comments: number;
  timestamp: string;
  isPremium?: boolean;
  type: "post" | "journal" | "image";
}

function PostCard({ post }: { post: Post }) {
  const [liked, setLiked] = useState(false);
  
  const toggleLike = () => {
    setLiked(!liked);
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const postTime = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - postTime.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s ago`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  return (
    <Card className="mb-4">
      <CardHeader className="p-4 pb-0 flex flex-row items-center gap-3">
        <Avatar className="h-10 w-10">
          <AvatarImage src={post.userAvatar || `https://api.dicebear.com/7.x/micah/svg?seed=${post.username}`} />
          <AvatarFallback>{post.username.charAt(0).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="flex flex-col">
          <div className="font-medium">{post.username}</div>
          <div className="text-xs text-muted-foreground">{formatTimeAgo(post.timestamp)}</div>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <p className="mb-3">{post.content}</p>
        
        {post.mediaUrl && (
          <div className="relative rounded-md overflow-hidden bg-gray-100">
            {post.type === "journal" ? (
              <div className="aspect-video relative">
                <video 
                  src={post.mediaUrl} 
                  className="w-full h-full object-cover" 
                  controls
                />
                <div className="absolute top-2 right-2 bg-violet-600 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                  <PlayCircleIcon className="h-3 w-3" />
                  Daily Journal
                </div>
              </div>
            ) : (
              <img 
                src={post.mediaUrl} 
                alt="Post media" 
                className="w-full h-auto rounded-md"
              />
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between">
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="sm"
            className={liked ? "text-red-500" : ""}
            onClick={toggleLike}
          >
            <HeartIcon className={`h-5 w-5 mr-1 ${liked ? "fill-current text-red-500" : ""}`} />
            {post.likes + (liked ? 1 : 0)}
          </Button>
          <Button variant="ghost" size="sm">
            <MessageCircleIcon className="h-5 w-5 mr-1" />
            {post.comments}
          </Button>
        </div>
        <Button variant="ghost" size="sm">
          <ShareIcon className="h-5 w-5 mr-1" />
          Share
        </Button>
      </CardFooter>
    </Card>
  );
}

export default function Home() {
  const { currentUser } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [activeTab, setActiveTab] = useState("feed");
  
  useEffect(() => {
    // In a real app, this would fetch from an API
    // For demo, we'll use localStorage or mock data
    const storedPosts = localStorage.getItem("loveoutloud_posts");
    if (storedPosts) {
      setPosts(JSON.parse(storedPosts));
    } else {
      // Initialize with mock data if no posts exist
      const mockPosts: Post[] = [
        {
          id: "post1",
          userId: "user123",
          username: "urban_creator",
          userAvatar: "https://api.dicebear.com/7.x/micah/svg?seed=urban_creator",
          content: "Just dropped a new beat! Check it out and let me know what you think. 🎵 #NewMusic #UrbanBeats",
          mediaUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800",
          likes: 42,
          comments: 7,
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          type: "post"
        },
        {
          id: "post2",
          userId: "user456",
          username: "melody_queen",
          userAvatar: "https://api.dicebear.com/7.x/micah/svg?seed=melody_queen",
          content: "Daily gratitude journal: Thankful for my family supporting my music journey. Much love to everyone who's been showing up for my livestreams! 💖 #GratitudeJournal #DailyVibes",
          mediaUrl: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800",
          likes: 128,
          comments: 24,
          timestamp: new Date(Date.now() - 86400000).toISOString(),
          type: "journal"
        }
      ];
      
      localStorage.setItem("urbanvibe_posts", JSON.stringify(mockPosts));
      setPosts(mockPosts);
    }
  }, []);

  const handleDailyJournal = () => {
    // In a real app, this would navigate to the journal page
    // For demo purposes, we'll just change the tab
    setActiveTab("journal");
  };

  return (
    <div className="container max-w-3xl px-4 py-6 mb-16 md:mb-0">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2 mb-6">
          <TabsTrigger value="feed">For You</TabsTrigger>
          <TabsTrigger value="journal">Journal</TabsTrigger>
        </TabsList>
        
        <TabsContent value="feed" className="space-y-4">
          {currentUser && (
            <div className="mb-6">
              <StreakTracker onCreateDailyPost={handleDailyJournal} />
            </div>
          )}
          
          {posts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
          
          {posts.length === 0 && (
            <div className="text-center py-12">
              <h3 className="text-xl font-medium">Welcome to UrbanVibe!</h3>
              <p className="text-muted-foreground mt-2">
                Follow creators to start building your feed
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="journal" className="space-y-4">
          <div className="bg-violet-50 dark:bg-gray-800 p-4 rounded-lg">
            <h3 className="font-medium text-lg">Daily Video Journal</h3>
            <p className="text-muted-foreground mt-1">
              Share your daily moments with loved ones through video journals.
              Keep a streak going to build consistency!
            </p>
            <Button 
              className="w-full mt-4 bg-violet-600 hover:bg-violet-700"
              onClick={() => setActiveTab("create")}
            >
              <PlayCircleIcon className="h-5 w-5 mr-2" />
              Create Today's Journal
            </Button>
          </div>
          
          {posts
            .filter(post => post.type === "journal")
            .map(post => (
              <PostCard key={post.id} post={post} />
            ))}
            
          {posts.filter(post => post.type === "journal").length === 0 && (
            <div className="text-center py-12">
              <h3 className="text-xl font-medium">No Journals Yet</h3>
              <p className="text-muted-foreground mt-2">
                Start your daily journal practice today!
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}