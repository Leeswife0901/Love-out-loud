const express = require('express');
const cors = require('cors');
const Stripe = require('stripe');
const bodyParser = require('body-parser');
const paypal = require('@paypal/checkout-server-sdk');
require('dotenv').config();

const app = express();
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

// PayPal Configuration
let paypalEnvironment;
if (process.env.NODE_ENV === 'production') {
  paypalEnvironment = new paypal.core.LiveEnvironment(
    process.env.PAYPAL_CLIENT_ID,
    process.env.PAYPAL_CLIENT_SECRET
  );
} else {
  paypalEnvironment = new paypal.core.SandboxEnvironment(
    process.env.PAYPAL_CLIENT_ID,
    process.env.PAYPAL_CLIENT_SECRET
  );
}
const paypalClient = new paypal.core.PayPalHttpClient(paypalEnvironment);

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Stripe Payment Intent
app.post('/api/create-payment-intent', async (req, res) => {
  const { amount, currency = 'usd', metadata = {} } = req.body;

  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency,
      metadata,
      payment_method_types: ['card'],
    });
    res.send({ clientSecret: paymentIntent.client_secret });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: err.message });
  }
});

// PayPal Order Creation
app.post('/api/create-paypal-order', async (req, res) => {
  const { amount } = req.body;
  
  const request = new paypal.orders.OrdersCreateRequest();
  request.prefer("return=representation");
  request.requestBody({
    intent: 'CAPTURE',
    purchase_units: [{
      amount: {
        currency_code: 'USD',
        value: (amount / 100).toFixed(2) // Convert from cents to dollars
      }
    }]
  });

  try {
    const order = await paypalClient.execute(request);
    res.json({ orderId: order.result.id });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: err.message });
  }
});

// Capture PayPal Order
app.post('/api/capture-paypal-order', async (req, res) => {
  const { orderID } = req.body;
  
  const request = new paypal.orders.OrdersCaptureRequest(orderID);
  request.requestBody({});

  try {
    const capture = await paypalClient.execute(request);
    res.json({ capture: capture.result });
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: err.message });
  }
});

// Cash App Pay API endpoint
app.post('/api/create-cashapp-payment', async (req, res) => {
  // This is a placeholder. Cash App Pay would require integration with their API
  // For now, we'll return a mock response
  res.json({ 
    success: true, 
    message: "Cash App Pay integration would be implemented here with their official SDK" 
  });
});

// Venmo API endpoint
app.post('/api/create-venmo-payment', async (req, res) => {
  // This is a placeholder. Venmo would require integration with Braintree SDK
  // For now, we'll return a mock response
  res.json({ 
    success: true, 
    message: "Venmo integration would be implemented here through Braintree" 
  });
});

// User API endpoints (mock for now)
app.get('/api/users', (req, res) => {
  // In production, this would fetch from a database
  const mockUsers = [
    { id: 1, email: 'user1@example.com', username: 'urbanuser1', hasPaid: true, followers: 120 },
    { id: 2, email: 'user2@example.com', username: 'urbanuser2', hasPaid: false, followers: 85 },
    { id: 3, email: 'user3@example.com', username: 'urbanuser3', hasPaid: true, followers: 230 },
  ];
  res.json(mockUsers);
});

// Social platform API endpoints
app.get('/api/feed', (req, res) => {
  // Mock social feed data
  const posts = [
    {
      id: 1,
      username: 'urbanuser1',
      content: 'Just dropped my new track! Check it out and support!',
      likes: 45,
      comments: 12,
      timestamp: new Date().toISOString()
    },
    {
      id: 2,
      username: 'urbanuser2',
      content: 'Live streaming tonight at 8PM. Exclusive content for supporters!',
      likes: 32,
      comments: 8,
      timestamp: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: 3,
      username: 'urbanuser3',
      content: 'Thanks for all the support on my latest project!',
      likes: 78,
      comments: 24,
      timestamp: new Date(Date.now() - 7200000).toISOString()
    }
  ];
  res.json(posts);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));