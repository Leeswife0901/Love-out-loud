import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/context/AuthContext";
import { 
  VideoIcon, 
  StopCircleIcon, 
  Loader2Icon, 
  RefreshCwIcon,
  SendIcon,
  TimerIcon,
  CheckIcon,
  TagIcon
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

interface VideoJournalProps {
  onPostComplete: () => void;
}

export default function VideoJournal({ onPostComplete }: VideoJournalProps) {
  const { currentUser } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [recordingInterval, setRecordingInterval] = useState<number | null>(null);
  const [recordedVideoURL, setRecordedVideoURL] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [caption, setCaption] = useState("");
  const [mood, setMood] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  
  useEffect(() => {
    return () => {
      // Clean up any recordings on unmount
      if (recordedVideoURL) {
        URL.revokeObjectURL(recordedVideoURL);
      }
      
      if (recordingInterval) {
        clearInterval(recordingInterval);
      }
      
      if (mediaRecorderRef.current && isRecording) {
        mediaRecorderRef.current.stop();
      }
    };
  }, [recordedVideoURL, recordingInterval, isRecording]);

  const startRecording = async () => {
    try {
      chunksRef.current = [];
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.muted = true; // Mute to prevent feedback
        videoRef.current.play();
      }
      
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };
      
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "video/webm" });
        const videoURL = URL.createObjectURL(blob);
        setRecordedVideoURL(videoURL);
        
        if (videoRef.current) {
          videoRef.current.srcObject = null;
          videoRef.current.src = videoURL;
          videoRef.current.muted = false;
          videoRef.current.play();
        }
        
        // Stop the camera stream
        const tracks = stream.getTracks();
        tracks.forEach(track => track.stop());
      };
      
      // Start recording
      mediaRecorder.start();
      setIsRecording(true);
      
      // Setup recording timer
      const interval = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
      setRecordingInterval(interval);
      
      // Auto-stop recording after 2 minutes (120 seconds)
      setTimeout(() => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
          stopRecording();
        }
      }, 120000);
      
    } catch (error) {
      console.error("Error accessing camera:", error);
      toast.error("Couldn't access your camera or microphone. Please check permissions.");
    }
  };
  
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      if (recordingInterval) {
        clearInterval(recordingInterval);
        setRecordingInterval(null);
      }
    }
  };
  
  const resetRecording = () => {
    if (recordedVideoURL) {
      URL.revokeObjectURL(recordedVideoURL);
      setRecordedVideoURL(null);
    }
    
    setRecordingTime(0);
    setCaption("");
    setMood("");
    setTags([]);
    setTagInput("");
  };
  
  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim()) && tags.length < 5) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };
  
  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };
  
  const handleSubmit = async () => {
    if (!recordedVideoURL) {
      toast.error("Please record a video first");
      return;
    }
    
    setIsUploading(true);
    
    try {
      // In a real app, this would upload to a server
      // For demo purposes, we'll simulate a successful upload
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Update streak in localStorage for demo
      const today = new Date().toISOString();
      const streakKey = `streak_${currentUser?.id}`;
      const storedStreak = localStorage.getItem(streakKey);
      
      let streak = {
        count: 1,
        lastPosted: today,
        history: [{ date: today, completed: true }]
      };
      
      if (storedStreak) {
        const parsedStreak = JSON.parse(storedStreak);
        const lastPostedDate = new Date(parsedStreak.lastPosted).toISOString().split('T')[0];
        const todayDate = new Date().toISOString().split('T')[0];
        
        if (lastPostedDate !== todayDate) {
          // Check if the last post was yesterday
          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);
          const yesterdayDate = yesterday.toISOString().split('T')[0];
          
          if (lastPostedDate === yesterdayDate) {
            // Streak continues
            parsedStreak.count += 1;
          } else {
            // Streak broken
            parsedStreak.count = 1;
          }
          
          parsedStreak.lastPosted = today;
          parsedStreak.history.push({ date: today, completed: true });
          streak = parsedStreak;
        }
      }
      
      localStorage.setItem(streakKey, JSON.stringify(streak));
      
      // Add post to local storage for demo
      const newPost = {
        id: `post_${Date.now()}`,
        userId: currentUser?.id,
        username: currentUser?.username,
        userAvatar: currentUser?.avatar,
        content: caption,
        mediaUrl: recordedVideoURL, // In a real app, this would be a server URL
        likes: 0,
        comments: 0,
        timestamp: new Date().toISOString(),
        type: "journal",
        tags: tags,
        mood: mood
      };
      
      const storedPosts = localStorage.getItem("urbanvibe_posts");
      const posts = storedPosts ? JSON.parse(storedPosts) : [];
      posts.unshift(newPost);
      localStorage.setItem("urbanvibe_posts", JSON.stringify(posts));
      
      toast.success("Journal posted successfully!");
      onPostComplete();
    } catch (error) {
      console.error("Error uploading video:", error);
      toast.error("Failed to upload your journal. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <VideoIcon className="h-5 w-5 text-violet-600" />
          Daily Video Journal
        </CardTitle>
        <CardDescription>
          Share your day with your loved ones through a quick video
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-5">
          {/* Video preview/recording area */}
          <div className="relative aspect-video rounded-md overflow-hidden bg-gray-100 border">
            {!recordedVideoURL && !isRecording && (
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <VideoIcon className="h-16 w-16 text-muted-foreground opacity-40" />
                <p className="text-sm text-muted-foreground mt-4">Ready to record your daily journal</p>
              </div>
            )}
            
            <video 
              ref={videoRef}
              className="w-full h-full object-cover" 
              controls={!isRecording && !!recordedVideoURL}
            />
            
            {isRecording && (
              <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-600 text-white px-3 py-1 rounded-full animate-pulse">
                <span className="h-2 w-2 rounded-full bg-white"></span>
                <span className="text-xs font-medium">RECORDING</span>
                <span className="text-xs">{formatTime(recordingTime)}</span>
              </div>
            )}
          </div>

          {/* Recording controls */}
          <div className="flex justify-center gap-3">
            {!isRecording && !recordedVideoURL && (
              <Button 
                onClick={startRecording} 
                className="bg-violet-600 hover:bg-violet-700 px-6"
              >
                <VideoIcon className="h-4 w-4 mr-2" />
                Start Recording
              </Button>
            )}
            
            {isRecording && (
              <Button 
                onClick={stopRecording} 
                variant="destructive" 
                className="px-6"
              >
                <StopCircleIcon className="h-4 w-4 mr-2" />
                Stop Recording
              </Button>
            )}
            
            {recordedVideoURL && (
              <Button 
                onClick={resetRecording} 
                variant="outline"
              >
                <RefreshCwIcon className="h-4 w-4 mr-2" />
                Record Again
              </Button>
            )}
          </div>
          
          {/* Post details form */}
          {recordedVideoURL && (
            <div className="pt-3 space-y-4">
              <Separator />
              
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={currentUser?.avatar || `https://api.dicebear.com/7.x/micah/svg?seed=${currentUser?.username}`} />
                  <AvatarFallback>{currentUser?.username?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{currentUser?.displayName || currentUser?.username}</p>
                  <p className="text-xs text-muted-foreground">Posting to: Daily Journal</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <Textarea 
                  placeholder="How was your day today?"
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  className="min-h-[100px]"
                />
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <TimerIcon className="h-4 w-4 text-violet-600" />
                      Today's Mood
                    </label>
                    <Input 
                      placeholder="How are you feeling?"
                      value={mood}
                      onChange={(e) => setMood(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <TagIcon className="h-4 w-4 text-violet-600" />
                      Add Tags
                    </label>
                    <div className="flex gap-2">
                      <Input 
                        placeholder="Add tag"
                        value={tagInput}
                        onChange={(e) => setTagInput(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && handleAddTag()}
                      />
                      <Button 
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={handleAddTag}
                      >
                        <CheckIcon className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
                
                {tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {tags.map(tag => (
                      <Badge 
                        key={tag} 
                        variant="outline"
                        className="cursor-pointer"
                        onClick={() => handleRemoveTag(tag)}
                      >
                        #{tag} ✕
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </CardContent>
      {recordedVideoURL && (
        <CardFooter className="flex justify-end">
          <Button 
            onClick={handleSubmit}
            disabled={isUploading}
            className="bg-violet-600 hover:bg-violet-700"
          >
            {isUploading ? (
              <>
                <Loader2Icon className="h-4 w-4 mr-2 animate-spin" />
                Posting...
              </>
            ) : (
              <>
                <SendIcon className="h-4 w-4 mr-2" />
                Post Journal
              </>
            )}
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}