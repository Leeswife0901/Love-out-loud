import React, { createContext, useState, useContext, useEffect } from "react";

export interface User {
  id: string;
  username: string;
  email?: string;
  avatar?: string;
  displayName?: string;
  bio?: string;
  hasPaid?: boolean;
  isVerified?: boolean;
  joinedAt: string;
  followers?: number;
  following?: number;
}

interface AuthContextType {
  currentUser: User | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Load user from localStorage on mount
    const loadUser = () => {
      const storedUser = localStorage.getItem("urbanvibe_user");
      if (storedUser) {
        setCurrentUser(JSON.parse(storedUser));
      }
      setIsLoading(false);
    };

    loadUser();
  }, []);

  const login = async (username: string, password: string) => {
    try {
      // In a real app, this would be an API call
      // For demo purposes, we'll simulate a successful login
      
      // Simulate network request
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Create a mock user
      const user: User = {
        id: `user_${Date.now()}`,
        username,
        displayName: username.charAt(0).toUpperCase() + username.slice(1),
        avatar: `https://api.dicebear.com/7.x/micah/svg?seed=${username}`,
        bio: "",
        hasPaid: false,
        isVerified: false,
        joinedAt: new Date().toISOString(),
        followers: 0,
        following: 0
      };
      
      // Store in localStorage
      localStorage.setItem("urbanvibe_user", JSON.stringify(user));
      
      setCurrentUser(user);
    } catch (error) {
      console.error("Login failed:", error);
      throw new Error("Login failed. Please check your credentials.");
    }
  };

  const register = async (username: string, email: string, password: string) => {
    try {
      // In a real app, this would be an API call
      // For demo purposes, we'll simulate a successful registration
      
      // Simulate network request
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Create a new user
      const user: User = {
        id: `user_${Date.now()}`,
        username,
        email,
        displayName: username.charAt(0).toUpperCase() + username.slice(1),
        avatar: `https://api.dicebear.com/7.x/micah/svg?seed=${username}`,
        bio: "",
        hasPaid: false,
        isVerified: false,
        joinedAt: new Date().toISOString(),
        followers: 0,
        following: 0
      };
      
      // Store in localStorage
      localStorage.setItem("urbanvibe_user", JSON.stringify(user));
      
      setCurrentUser(user);
    } catch (error) {
      console.error("Registration failed:", error);
      throw new Error("Registration failed. Please try again later.");
    }
  };

  const logout = () => {
    localStorage.removeItem("urbanvibe_user");
    setCurrentUser(null);
  };

  const updateUser = (userData: Partial<User>) => {
    if (!currentUser) return;
    
    const updatedUser = { ...currentUser, ...userData };
    localStorage.setItem("urbanvibe_user", JSON.stringify(updatedUser));
    setCurrentUser(updatedUser);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isLoading,
        login,
        register,
        logout,
        updateUser
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};