import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/context/AuthContext";
import VideoJournal from "@/components/social/VideoJournal";
import StreakTracker from "@/components/social/StreakTracker";
import { CalendarIcon, VideoIcon, UserIcon } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

export default function Journal() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("create");
  
  // If not logged in, prompt to login
  if (!currentUser) {
    return (
      <div className="container max-w-lg px-4 py-12">
        <Card>
          <CardHeader>
            <CardTitle>Login Required</CardTitle>
            <CardDescription>You need to be logged in to create and view your journals</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center pb-6">
            <button
              onClick={() => navigate("/login")}
              className="px-6 py-3 bg-violet-600 text-white rounded-md hover:bg-violet-700"
            >
              Login to Continue
            </button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const handleJournalComplete = () => {
    toast.success("Journal posted successfully!");
    navigate("/");
  };
  
  const handleStreakJournal = () => {
    setActiveTab("create");
  };

  return (
    <div className="container max-w-4xl px-4 py-6 mb-16 md:mb-0">
      <div className="flex flex-col md:flex-row md:gap-8">
        {/* Sidebar with streak info */}
        <div className="w-full md:w-1/3 mb-6 md:mb-0">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserIcon className="h-5 w-5 text-violet-600" />
                  Your Journal
                </CardTitle>
              </CardHeader>
              <CardContent>
                <StreakTracker onCreateDailyPost={handleStreakJournal} />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Journal Tips</CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-3">
                <div className="flex items-start gap-2">
                  <VideoIcon className="h-4 w-4 text-violet-600 mt-0.5" />
                  <p>Keep your videos under 2 minutes for best engagement</p>
                </div>
                <div className="flex items-start gap-2">
                  <CalendarIcon className="h-4 w-4 text-violet-600 mt-0.5" />
                  <p>Consistency is key - try to post daily to build your streak</p>
                </div>
                <div className="flex items-start gap-2">
                  <UserIcon className="h-4 w-4 text-violet-600 mt-0.5" />
                  <p>Tag loved ones to share your journal directly with them</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        {/* Main content */}
        <div className="w-full md:w-2/3">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 mb-6">
              <TabsTrigger value="create">Create Journal</TabsTrigger>
              <TabsTrigger value="history">Journal History</TabsTrigger>
            </TabsList>
            
            <TabsContent value="create">
              <VideoJournal onPostComplete={handleJournalComplete} />
            </TabsContent>
            
            <TabsContent value="history">
              <div className="space-y-4">
                {/* In a real app, we would fetch and display the user's journal history */}
                <Card>
                  <CardHeader>
                    <CardTitle>Your Journal History</CardTitle>
                    <CardDescription>
                      A history of your daily video journals
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="text-center py-10">
                    {/* This would be replaced with actual journal entries */}
                    <VideoIcon className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-40" />
                    <p className="text-muted-foreground">
                      Your journal history will appear here
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}