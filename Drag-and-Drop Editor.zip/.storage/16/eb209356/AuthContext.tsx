import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User } from "@/types";

type AuthContextType = {
  currentUser: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateProfile: (userData: Partial<User>) => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem("urbanvibe_user");
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // Mock login - in a real app, this would be an API call
      // For demo purposes, we'll use a predefined user
      const mockUser: User = {
        id: "user1",
        username: "urbanuser1",
        email,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
        bio: "Urban music enthusiast and content creator",
        followers: 120,
        following: 85,
        hasPaid: false,
        joinedDate: new Date().toISOString(),
      };
      
      setCurrentUser(mockUser);
      localStorage.setItem("urbanvibe_user", JSON.stringify(mockUser));
    } catch (error) {
      console.error("Login error:", error);
      throw new Error("Failed to log in");
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (username: string, email: string, password: string) => {
    setIsLoading(true);
    try {
      // Mock registration - in a real app, this would be an API call
      const newUser: User = {
        id: `user${Date.now()}`,
        username,
        email,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
        bio: "",
        followers: 0,
        following: 0,
        hasPaid: false,
        joinedDate: new Date().toISOString(),
      };
      
      setCurrentUser(newUser);
      localStorage.setItem("urbanvibe_user", JSON.stringify(newUser));
    } catch (error) {
      console.error("Registration error:", error);
      throw new Error("Failed to register");
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem("urbanvibe_user");
  };

  const updateProfile = async (userData: Partial<User>) => {
    if (!currentUser) return;
    
    try {
      const updatedUser = { ...currentUser, ...userData };
      setCurrentUser(updatedUser);
      localStorage.setItem("urbanvibe_user", JSON.stringify(updatedUser));
    } catch (error) {
      console.error("Profile update error:", error);
      throw new Error("Failed to update profile");
    }
  };

  const value = {
    currentUser,
    isLoading,
    login,
    register,
    logout,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};